import React from "react";
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from "react-native";

const tournaments = [
  {
    game: "Free Fire",
    type: "Solo",
    time: "2:00 PM",
    fee: "৳50",
  },
  {
    game: "Free Fire",
    type: "Duo",
    time: "4:00 PM",
    fee: "৳50",
  },
  {
    game: "Ludo",
    type: "Classic",
    time: "6:00 PM",
    fee: "৳30",
  },
];

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>GameZone</Text>
      <ScrollView style={styles.scroll}>
        {tournaments.map((t, i) => (
          <View key={i} style={styles.card}>
            <Text style={styles.title}>{\`\${t.game} - \${t.type}\`}</Text>
            <Text style={styles.info}>Time: {t.time}</Text>
            <Text style={styles.info}>Entry Fee: {t.fee}</Text>
            <TouchableOpacity style={styles.button}>
              <Text style={styles.buttonText}>Join</Text>
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>
      <Text style={styles.footer}>Powered by Rayhan Parvaz</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#000",
    padding: 20,
    paddingTop: 50,
  },
  header: {
    fontSize: 30,
    fontWeight: "bold",
    color: "#FFD700",
    marginBottom: 20,
  },
  scroll: {
    marginBottom: 20,
  },
  card: {
    backgroundColor: "#111",
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
  },
  title: {
    fontSize: 20,
    color: "#fff",
    fontWeight: "bold",
  },
  info: {
    color: "#ccc",
    marginTop: 4,
  },
  button: {
    marginTop: 10,
    backgroundColor: "#FFD700",
    padding: 10,
    borderRadius: 8,
    alignItems: "center",
  },
  buttonText: {
    color: "#000",
    fontWeight: "bold",
  },
  footer: {
    color: "#888",
    textAlign: "center",
    marginTop: 10,
  },
});